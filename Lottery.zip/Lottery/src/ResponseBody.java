import java.util.Arrays;

public class ResponseBody {
	private Result[] result = null;
	private int ret_code = 0;

	public Result[] getResult() {
		return result;
	}

	public void setResult(Result[] result) {
		this.result = result;
	}

	public int getRet_code() {
		return ret_code;
	}

	public void setRet_code(int ret_code) {
		this.ret_code = ret_code;
	}

	@Override
	public String toString() {
		return "ResponseBody [result=" + Arrays.toString(result) + ", ret_code=" + ret_code + "]";
	}

}
