
public class Result {
	private int timestamp = 0;
	private String expect = null;
	private String time = null;
	private String name = null;
	private String code = null;
	private String openCode = null;

	public int getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(int timestamp) {
		this.timestamp = timestamp;
	}

	public String getExpect() {
		return expect;
	}

	public void setExpect(String expect) {
		this.expect = expect;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getOpenCode() {
		return openCode;
	}

	public void setOpenCode(String openCode) {
		this.openCode = openCode;
	}

	@Override
	public String toString() {
		return "Result [timestamp=" + timestamp + ", expect=" + expect + ", time=" + time + ", name=" + name + ", code="
				+ code + ", openCode=" + openCode + "]";
	}

}
