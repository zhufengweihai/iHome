import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.google.gson.Gson;
import com.show.api.ShowApiRequest;

public class Main {

	public static void main(String[] args) throws IOException, InterruptedException, ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = dateFormat.format(new Date());
		List<Result> results = new ArrayList<>(10000);
		for (int i = 0;; i++) {
			String res = new ShowApiRequest("http://route.showapi.com/44-2", "31607",
					"a5858af94b274596b7e175634a2ed269").addTextPara("code", "cqssc").addTextPara("endTime", time)
							.addTextPara("count", "50").post();

			Lottery lottery = new Gson().fromJson(res, Lottery.class);
			Result[] result = lottery.getShowapi_res_body().getResult();
			for (Result result2 : result) {
				results.add(result2);
			}
			if (result.length < 50) {
				break;
			}
			Date date = dateFormat.parse(result[result.length - 1].getTime());
			date.setTime(date.getTime() - 60000);
			time = dateFormat.format(date);
			if (i % 15 == 9) {
				Thread.sleep(20000);
			}
		}

		HSSFWorkbook wb = new HSSFWorkbook(); // --->������һ��excel�ļ�
		HSSFSheet sheet = wb.createSheet("�����ʽ𱨱�"); // --->������һ��������

		int s = results.size() - 1;
		for (int i = 0; i <= s; i++) {
			Result result = results.get(s - i);
			String[] numbers = result.getOpenCode().split(",");
			HSSFRow row = sheet.createRow(i);
			HSSFCell cell = row.createCell(0);
			cell.setCellValue(result.getTime());
			for (int j = 0; j < numbers.length; j++) {
				cell = row.createCell(j + 1);
				cell.setCellValue(numbers[j]);
			}
		}

		FileOutputStream fileOut = new FileOutputStream("d:\\workbook3.xls");
		wb.write(fileOut);
	}

}
